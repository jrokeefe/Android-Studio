package com.jack.retro;

import java.util.ArrayList;


public class ObstacleManager {
    private ArrayList<Obstacle> obstacles;
    private int playerGap;

    public ObstacleManager(int playerGap) {
        this.playerGap = playerGap;

        obstacles = new ArrayList<>();

        populateObstacles();
    }

    private void populateObstacles() {
        int currY = -5*Constants.SCREEN_HEIGHT/4;
        while(obstacles.get(obstacles.size() - 1).getRectangle().bottom < 0) {

        }
    }
}
