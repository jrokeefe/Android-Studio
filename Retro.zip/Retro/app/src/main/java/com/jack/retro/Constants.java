package com.jack.retro;

public class Constants {
    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;
}
