package com.example.thequizzler;

public class Question {
    private int mTextResld;
    private boolean mAnswerTrue;

    public Question(int textResld, boolean answerTrue) {
        mTextResld = textResld;
        mAnswerTrue = answerTrue;
    }

    public int getTextResld() {
        return mTextResld;
    }

    public void setTextResld(int textResld) {
        mTextResld = textResld;
    }

    public boolean isAnswerTrue() {
        return mAnswerTrue;
    }

    public void setAnswerTrue(boolean answerTrue) {
        mAnswerTrue = answerTrue;
    }
}
