package com.example.thequizzler;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button mTrueButton;
    private Button mFalseButton;
    private Button mNextButton;
    private Button mPreviousButton;
    private TextView mQuestionTextView;
    private Question[] mQuestionBank = new Question[] {
            new Question(R.string.question_madison, true),
            new Question(R.string.question_milwaukee, false),
            new Question(R.string.question_chicago, true),
            new Question(R.string.question_bird, true),
            new Question(R.string.question_tree, false),
            new Question(R.string.question_midwest, false)
    };
    private int mCurrentIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);

        projectQuestion();

        mTrueButton = (Button) findViewById(R.id.true_button);
            mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
                   public void onClick(View v) {
                        Toast.makeText(MainActivity.this, R.string.correct_toast,Toast.LENGTH_SHORT).show();
            }

            });
        mFalseButton = (Button) findViewById(R.id.false_button);
            mFalseButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(MainActivity.this, R.string.incorrect_toast,Toast.LENGTH_SHORT).show();
                }

            });
        mNextButton = (Button) findViewById(R.id.next_button);
            mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
                    public void onClick(View v) {
                        if (mCurrentIndex == 5) {
                            mCurrentIndex = 0;
                        }
                        else {
                            mCurrentIndex ++;
                        }
                                             // the app crashes when mCurrentIndex gets to 6
                                            // sol: we want to prevent mCurrentIndex from getting to 6
                                            // sol cont: we want mCurrentIndex to go from 5 to 0
                                                // if mCurrentIndex is 5, go back to 0
                                                // otherwise, mCurrentIndex increases by 1
                        projectQuestion();
            }
        });
            mPreviousButton = (Button) findViewById(R.id.previous_button);
            mPreviousButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mCurrentIndex == 0) {
                        mCurrentIndex = 5;
                    } else {
                        mCurrentIndex--;
                    }
                }
            }

    private void projectQuestion() {
        int question = mQuestionBank[mCurrentIndex].getTextResld();
        mQuestionTextView.setText(question);
    }

    private void checkAnswer(boolean userPressedTrue) {
        boolean answerIsTrue == mQuestionBank[mCurrentIndex].isAnswerTrue();

        int messageResld = 0;

        if (userPressedTrue == answerIsTrue) {
            messageResld = R.string.correct_toast;
            else {
                messageResld = R.string.incorrect_toast;

                Toast.makeText(this, messageResld, Toast.LENGTH_SHORT).show();
            }

        }

    }